# Generierung des secret keys nach Anleitung aus der Flask-Doku
# http://flask.pocoo.org/docs/quickstart/#sessions
SECRET_KEY = '\xca%6\xa4}\xb2K\xd4L\x94{\x08\xf5 \x06\xeaD\x89\xd2\xc9\x10\xcb\xcd4'

# Angabe von Informationen zur Datenbank
DB_URI = 'sqlite:///search.db'
